import json
import time
import random
from kafka import KafkaProducer

producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

machines = ["M001", "M002", "M003"]

print("Kafka IoT Producer started ...")

try:
    while True:
        data = {
            "machine_id": random.choice(machines),
            "temperature": round(random.uniform(20, 100), 2),
            "vibration": round(random.uniform(0, 5), 3),
            "timestamp": time.time()
        }

        producer.send("tp07-iot", value=data)
        print("Sent:", data)
        time.sleep(1)

except KeyboardInterrupt:
    print("Producer stopped")

producer.close()
