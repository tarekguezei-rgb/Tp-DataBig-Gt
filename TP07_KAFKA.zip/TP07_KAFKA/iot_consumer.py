import json
import csv
from kafka import KafkaConsumer

consumer = KafkaConsumer(
    "tp07-iot",
    bootstrap_servers="localhost:9092",
    auto_offset_reset="earliest",
    group_id="iot-group",
    value_deserializer=lambda x: json.loads(x.decode("utf-8"))
)

print("Kafka IoT Consumer started ...")

with open("iot_data.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["machine_id", "temperature", "vibration", "timestamp"])

    for msg in consumer:
        data = msg.value
        print("Received:", data)

        writer.writerow([
            data["machine_id"],
            data["temperature"],
            data["vibration"],
            data["timestamp"]
        ])

        if data["temperature"] > 80:
            print("⚠️ ALERT: High Temperature for", data["machine_id"])
